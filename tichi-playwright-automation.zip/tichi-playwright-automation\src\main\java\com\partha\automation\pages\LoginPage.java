package com.partha.automation.pages;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public class LoginPage {

    private final Page page;

    public LoginPage(Page page) {
        this.page = page;
    }

    public void open(String url) {
        page.navigate(url);
    }

    public void enterEmail(String email) {
        page.getByRole(
                AriaRole.TEXTBOX,
                new Page.GetByRoleOptions().setName("Email Address *"))
                .fill(email);
    }

    public void clickContinue() {
        page.getByRole(
                AriaRole.BUTTON,
                new Page.GetByRoleOptions()
                        .setName("Continue")
                        .setExact(true))
                .click();
    }

    public void enterPassword(String password) {
        page.getByRole(
                AriaRole.TEXTBOX,
                new Page.GetByRoleOptions().setName("Password *"))
                .fill(password);
    }

    public void clickLogin() {
        page.getByRole(
                AriaRole.BUTTON,
                new Page.GetByRoleOptions().setName("Login"))
                .click();
    }

    public void login(String email, String password) {

        enterEmail(email);

        clickContinue();

        enterPassword(password);

        clickLogin();
    }

    public String getCurrentUrl() {
        return page.url();
    }

    public boolean isWelcomeDisplayed() {
        return page.locator("text=Welcome to Tichi").isVisible();
    }
    public boolean isLoginErrorDisplayed() {
    	page.waitForTimeout(2000);

        return page.locator("text=Invalid credentials").isVisible();

    }
    
}