package com.partha.automation.base;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.partha.automation.utils.ConfigReader;

public class BrowserFactory {

    private static Playwright playwright;
    private static Browser browser;
    private static Page page;

    public static Page launchBrowser() {

        playwright = Playwright.create();

        boolean headless = Boolean.parseBoolean(
                ConfigReader.get("headless"));

        int slowMo = Integer.parseInt(
                ConfigReader.get("slowMo"));

        browser = playwright.chromium().launch(

                new BrowserType.LaunchOptions()

                        .setHeadless(headless)

                        .setSlowMo((double) slowMo)

        );

        page = browser.newPage();

        page.setDefaultTimeout(60000);

        page.navigate(ConfigReader.get("baseUrl"));

        return page;
    }

    public static void closeBrowser() {

        if (page != null)
            page.close();

        if (browser != null)
            browser.close();

        if (playwright != null)
            playwright.close();

    }

}