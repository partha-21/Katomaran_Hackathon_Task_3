package com.partha.automation.tests;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.microsoft.playwright.Page;
import com.partha.automation.base.BrowserFactory;
import com.partha.automation.pages.LoginPage;
import com.partha.automation.utils.ConfigReader;

public class LoginTest {

    private Page page;
    private LoginPage loginPage;

    @BeforeEach
    public void setup() {

        page = BrowserFactory.launchBrowser();

        loginPage = new LoginPage(page);

    }

    @Test
    public void validLoginTest() {

        loginPage.login(

                ConfigReader.get("email"),

                ConfigReader.get("password")

        );

        Assertions.assertTrue(

                loginPage.isWelcomeDisplayed(),

                "Login Failed"

        );

        System.out.println("Login Successful");

    }
    @Test
    public void invalidPasswordTest() {

        loginPage.login(
                ConfigReader.get("email"),
                "WrongPassword_123"
        );

        page.waitForTimeout(3000);

        // User should still see the Login button
        Assertions.assertTrue(
            page.getByRole(
                com.microsoft.playwright.options.AriaRole.BUTTON,
                new Page.GetByRoleOptions().setName("Login")
            ).isVisible(),
            "User should remain on the login page."
        );
        System.out.println(page.locator("body").innerText());
    }
    @AfterEach
    public void tearDown() {

        BrowserFactory.closeBrowser();

    }

}